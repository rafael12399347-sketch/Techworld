"use client"
import Link from "next/link"
import { useEffect } from "react"
import { ChevronLeft, ChevronRight, BookOpen, Clock, CheckCircle, Target, Lightbulb } from "lucide-react"

const cursosData = [
  {
    id: "javascript-fundamentos",
    title: "Fundamentos de JavaScript",
    level: "Iniciante",
    color: "from-primary",
    weeks: [
      {
        week: 1,
        title: "Variáveis, Tipos e Operadores",
        objectives: [
          "Entender como declarar e usar variáveis (var, let, const)",
          "Dominar todos os tipos de dados em JavaScript",
          "Usar operadores aritméticos, lógicos e de comparação",
          "Trabalhar com template literals",
        ],
        image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=400&fit=crop",
        introduction:
          "Nesta primeira semana, você aprenderá os fundamentos essenciais que toda a programação em JavaScript se baseia. Variáveis são como caixas onde guardamos informações, tipos definem que tipo de informação podemos guardar, e operadores nos ajudam a fazer cálculos e comparações.",
        sections: [
          {
            title: "Variáveis: var, let e const",
            content:
              "As variáveis são formas de armazenar dados. Existem 3 formas:\n\n• VAR: forma antiga, escopo global ou função\n• LET: forma moderna, escopo de bloco\n• CONST: constante, não pode ser alterada\n\nExemplo:\nconst nome = 'João';\nlet idade = 25;\nvar cidade = 'São Paulo';",
            tip: "Prefira usar 'const' por padrão, 'let' quando precisar reatribuir, e evite 'var'.",
          },
          {
            title: "Tipos de Dados",
            content:
              "JavaScript tem 7 tipos primitivos:\n\n• String: 'texto', \"texto\"\n• Number: 123, 3.14, -5\n• Boolean: true, false\n• Null: ausência intencional\n• Undefined: não atribuído\n• Symbol: valor único\n• BigInt: números muito grandes\n\nExemplo:\nconst texto = 'Olá';\nconst numero = 42;\nconst ativo = true;",
            tip: "Use typeof para descobrir o tipo: typeof 42 retorna 'number'",
          },
          {
            title: "Operadores",
            content:
              "Operadores realizam ações em variáveis.\n\nAritméticos: +, -, *, /, %, **\nComparação: ==, ===, !=, !==, <, >, <=, >=\nLógicos: && (e), || (ou), ! (não)\n\nExemplo:\n5 + 3 === 8 // true\n10 > 5 && 5 < 20 // true\n!false // true",
            tip: "Use === em vez de ==, pois === compara sem conversão de tipo",
          },
        ],
        exercises: [
          "Crie 5 variáveis diferentes e exiba seus valores no console",
          "Use operadores aritméticos para calcular 2 + 3 * 4 - 10",
          "Crie um script que verifica se um número é positivo e par",
          "Use template literals para criar uma mensagem com variáveis",
        ],
        project: "Crie uma calculadora de IMC que pergunta peso e altura, calcula e exibe o resultado",
      },
      {
        week: 2,
        title: "Funções, Loops e Condições",
        objectives: [
          "Criar e usar funções efetivamente",
          "Entender arrow functions",
          "Dominar estruturas condicionais (if/else)",
          "Usar loops para repetir código",
        ],
        image: "https://images.unsplash.com/photo-1516321318423-f06f70d504c0?w=800&h=400&fit=crop",
        introduction:
          "Funções são blocos de código reutilizáveis que realizam tarefas específicas. Condições permitem tomar decisões no código, e loops repetem código várias vezes.",
        sections: [
          {
            title: "Funções",
            content:
              "Funções encapsulam código reutilizável.\n\nDeclaração:\nfunction saudar(nome) {\n  return `Olá, ${nome}!`;\n}\n\nArrow Function:\nconst saudar = (nome) => `Olá, ${nome}!`;\n\nChamada:\nsaudar('Maria'); // 'Olá, Maria!'",
            tip: "Arrow functions são mais concisas, mas regular functions têm seus usos",
          },
          {
            title: "Condições (if/else/switch)",
            content:
              "Permitem executar código condicionalmente.\n\nif/else:\nif (idade >= 18) {\n  console.log('Maior de idade');\n} else {\n  console.log('Menor de idade');\n}\n\nswitch:\nswitch (diaSemana) {\n  case 'segunda':\n    console.log('Início da semana');\n    break;\n  default:\n    console.log('Outro dia');\n}",
            tip: "Use switch para múltiplas condições, if/else para lógica complexa",
          },
          {
            title: "Loops (for, while)",
            content:
              "Repetem código várias vezes.\n\nFor:\nfor (let i = 0; i < 5; i++) {\n  console.log(i);\n}\n\nWhile:\nlet contador = 0;\nwhile (contador < 5) {\n  console.log(contador);\n  contador++;\n}\n\nFor...of:\nfor (const numero of [1, 2, 3]) {\n  console.log(numero);\n}",
            tip: "Cuidado com loops infinitos! Sempre tenha condição de parada",
          },
        ],
        exercises: [
          "Crie uma função que calcula a tabuada de um número",
          "Use um loop para exibir números de 1 a 10",
          "Crie uma função que verifica se um número é primo",
          "Use if/else para criar um programa que valida idade",
        ],
        project: "Jogo de adivinhação: o programa pensa em um número, você tenta adivinhar com dicas",
      },
      {
        week: 3,
        title: "DOM e Manipulação de Eventos",
        objectives: [
          "Entender a estrutura do DOM",
          "Selecionar elementos HTML",
          "Modificar conteúdo e estilos dinamicamente",
          "Responder a eventos de usuário",
        ],
        image: "https://images.unsplash.com/photo-1633356122544-f134324ef6e2?w=800&h=400&fit=crop",
        introduction:
          "O DOM (Document Object Model) é a representação da página HTML em JavaScript. Você pode selecionar elementos, modificá-los e responder a ações do usuário.",
        sections: [
          {
            title: "Selecionando Elementos",
            content:
              "Diferentes formas de selecionar elementos:\n\nById:\ndocument.getElementById('id');\n\nClass:\ndocument.querySelector('.classe');\ndocument.querySelectorAll('.classe');\n\nTag:\ndocument.getElementsByTagName('div');\n\nSelector CSS:\ndocument.querySelector('div > p');\ndocument.querySelectorAll('div.ativo');",
            tip: "querySelector e querySelectorAll são os mais flexíveis e modernos",
          },
          {
            title: "Modificando o DOM",
            content:
              "Altere conteúdo e estilos.\n\nConteúdo:\nelement.textContent = 'Novo texto';\nelement.innerHTML = '<p>HTML aqui</p>';\n\nAtributos:\nelement.setAttribute('class', 'nova-classe');\nelement.getAttribute('id');\n\nEstilos:\nelement.style.color = 'red';\nelement.style.backgroundColor = 'blue';\n\nClasses:\nelement.classList.add('ativa');\nelement.classList.remove('inativa');",
            tip: "Use classList para adicionar/remover classes, é mais organizado",
          },
          {
            title: "Event Listeners",
            content:
              "Responda a ações do usuário.\n\nAdicionar listener:\nelement.addEventListener('click', () => {\n  console.log('Clicado!');\n});\n\nEventos comuns:\nclick, submit, change, input, mouseover, keydown\n\nAcesso ao evento:\nelement.addEventListener('click', (event) => {\n  console.log(event.target);\n});",
            tip: "addEventListener permite múltiplos listeners no mesmo elemento",
          },
        ],
        exercises: [
          "Selecione elementos e mude sua cor ao clicar",
          "Crie um botão que adiciona/remove uma classe CSS",
          "Modifique o textContent de um elemento dinamicamente",
          "Crie um contador que aumenta ao clicar em um botão",
        ],
        project: "To-Do List: adicione, marque como concluído e delete tarefas",
      },
      {
        week: 4,
        title: "Async/Await, Promises e APIs",
        objectives: [
          "Entender código assíncrono",
          "Usar Promises e Async/Await",
          "Consumir dados de APIs",
          "Armazenar dados localmente",
        ],
        image: "https://images.unsplash.com/photo-1526374965328-7f5ae4e8b08e?w=800&h=400&fit=crop",
        introduction:
          "APIs permitem buscar dados de servidores remotos. Async/Await torna este código mais legível que callbacks ou promises.",
        sections: [
          {
            title: "Promises e Async/Await",
            content:
              "Promises lidam com operações assíncronas.\n\nPromise:\nfetch('/dados')\n  .then(response => response.json())\n  .catch(error => console.error(error));\n\nAsync/Await (moderno):\nasync function buscarDados() {\n  try {\n    const response = await fetch('/dados');\n    const dados = await response.json();\n    console.log(dados);\n  } catch (error) {\n    console.error(error);\n  }\n}",
            tip: "Prefira async/await, é mais legível e fácil de entender",
          },
          {
            title: "Fetch API",
            content:
              "Busque dados de APIs.\n\nGET simples:\nconst dados = await fetch('https://api.exemplo.com/usuarios')\n  .then(r => r.json());\n\nPOST com dados:\nconst response = await fetch('/api', {\n  method: 'POST',\n  headers: { 'Content-Type': 'application/json' },\n  body: JSON.stringify({ nome: 'João' })\n});\n\nTratamento de erros:\ntry {\n  const dados = await fetch(url);\n  if (!dados.ok) throw new Error('Erro na requisição');\n} catch (error) {\n  console.error(error);\n}",
            tip: "Sempre trate erros com try/catch ou .catch()",
          },
          {
            title: "LocalStorage",
            content:
              "Armazene dados no navegador.\n\nSalvar:\nlocalStorage.setItem('usuario', JSON.stringify(dados));\n\nRecuperar:\nconst usuario = JSON.parse(localStorage.getItem('usuario'));\n\nRemover:\nlocalStorage.removeItem('usuario');\nlocalStorage.clear(); // remove tudo\n\nDados persistem até ser deletados!",
            tip: "LocalStorage só armazena strings, use JSON.stringify/parse",
          },
        ],
        exercises: [
          "Busque dados de uma API pública (JSONPlaceholder)",
          "Exiba os dados na página",
          "Salve dados no localStorage",
          "Recupere dados do localStorage ao carregar a página",
        ],
        project: "App de Clima: busca dados da API, exibe temperatura e salva últimas buscas",
      },
    ],
  },
  {
    id: "react-zero",
    title: "React do Zero",
    level: "Iniciante",
    color: "from-secondary",
    weeks: [
      {
        week: 1,
        title: "Conceitos Básicos e JSX",
        objectives: [
          "Entender o que é React",
          "Dominar a sintaxe JSX",
          "Criar componentes funcionais",
          "Passar props entre componentes",
        ],
        image: "https://images.unsplash.com/photo-1633356122544-f134324ef6e2?w=800&h=400&fit=crop",
        introduction:
          "React é uma biblioteca JavaScript para construir interfaces interativas. Componentes são blocos reutilizáveis que formam sua aplicação.",
        sections: [
          {
            title: "O que é React e JSX",
            content:
              "React usa JSX, que mistura JavaScript com HTML.\n\nComponente simples:\nfunction Saudacao() {\n  return <h1>Olá, Mundo!</h1>;\n}\n\nCom JavaScript:\nfunction Saudacao({ nome }) {\n  const mensagem = `Bem-vindo, ${nome}`;\n  return <h1>{mensagem}</h1>;\n}\n\nJSX é convertido para JavaScript:\n// JSX:\n<button>Clique</button>\n\n// Vira:\nReact.createElement('button', null, 'Clique');",
            tip: "JSX deve retornar um único elemento raiz, use <> </> se necessário",
          },
          {
            title: "Componentes e Props",
            content:
              'Componentes são funções que retornam JSX.\n\nComponente:\nfunction Card({ titulo, descricao }) {\n  return (\n    <div>\n      <h2>{titulo}</h2>\n      <p>{descricao}</p>\n    </div>\n  );\n}\n\nUsando:\n<Card titulo="Título" descricao="Descrição" />\n\nProps são argumentos passados ao componente!',
            tip: "Componentes devem começar com letra MAIÚSCULA",
          },
          {
            title: "Estrutura de Projeto",
            content:
              "Organize seu projeto React.\n\nEstrutura típica:\napp/\n  components/\n    Card.jsx\n    Header.jsx\n  pages/\n    Home.jsx\n  App.jsx\n\nComponentes são reutilizáveis e organizados em pastas.",
            tip: "Um componente por arquivo, facilita manutenção",
          },
        ],
        exercises: [
          "Crie um componente Saudação com uma prop nome",
          "Crie um componente Card que recebe titulo e descrição",
          "Reutilize o componente Card 3 vezes com dados diferentes",
          "Crie um componente botão reutilizável",
        ],
        project: "Portfólio: crie cards para seus projetos com foto, título e descrição",
      },
      {
        week: 2,
        title: "Props, State e Hooks",
        objectives: [
          "Gerenciar estado com useState",
          "Usar useEffect para efeitos colaterais",
          "Entender ciclo de vida de componentes",
          "Criar componentes interativos",
        ],
        image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=400&fit=crop",
        introduction:
          "State é dados que podem mudar. Hooks permitem adicionar estado e outras funcionalidades aos componentes funcionais.",
        sections: [
          {
            title: "useState: Gerenciando Estado",
            content:
              "Estado permite que componentes se lembrem de dados.\n\nSintaxe:\nconst [contador, setContador] = useState(0);\n\nUsando:\nfunction Contador() {\n  const [count, setCount] = useState(0);\n  \n  return (\n    <div>\n      <p>Contador: {count}</p>\n      <button onClick={() => setCount(count + 1)}>\n        Aumentar\n      </button>\n    </div>\n  );\n}\n\nEstado é imutável, sempre use setState!",
            tip: "Cada componente tem seu próprio state independente",
          },
          {
            title: "useEffect: Efeitos Colaterais",
            content:
              "useEffect roda código após renderizar.\n\nSem dependências (roda toda renderização):\nuseEffect(() => {\n  console.log('Componente renderizou');\n});\n\nCom dependências vazias (roda 1x):\nuseEffect(() => {\n  console.log('Componente montou');\n}, []);\n\nCom dependências (roda quando mudam):\nuseEffect(() => {\n  console.log('Count mudou para', count);\n}, [count]);\n\nLimpeza:\nuseEffect(() => {\n  const timer = setInterval(() => {}, 1000);\n  return () => clearInterval(timer);\n}, []);",
            tip: "Sempre limpe subscriptions e timers em useEffect",
          },
          {
            title: "Formulários Controlados",
            content:
              "Inputs com estado em React.\n\nComponente:\nfunction Formulario() {\n  const [email, setEmail] = useState('');\n  \n  return (\n    <input\n      value={email}\n      onChange={(e) => setEmail(e.target.value)}\n      placeholder=\"Email\"\n    />\n  );\n}\n\nO React controla o valor do input!",
            tip: "Inputs não-controlados com refs devem ser evitados",
          },
        ],
        exercises: [
          "Crie um contador com aumentar/diminuir",
          "Crie um formulário que exibe o que você digita em tempo real",
          "Use useEffect para buscar dados quando componente monta",
          "Crie um toggle de tema claro/escuro",
        ],
        project: "Timer: contador regressivo com start, pause e reset",
      },
      {
        week: 3,
        title: "Componentes Complexos e Renderização",
        objectives: [
          "Renderizar listas dinamicamente",
          "Usar renderização condicional",
          "Compor componentes aninhados",
          "Melhorar performance",
        ],
        image: "https://images.unsplash.com/photo-1633356122544-f134324ef6e2?w=800&h=400&fit=crop",
        introduction: "Listas e renderização condicional são essenciais para criar UIs dinâmicas em React.",
        sections: [
          {
            title: "Renderizando Listas",
            content:
              "Use .map() para renderizar listas.\n\nExemplo:\nconst usuarios = [\n  { id: 1, nome: 'João' },\n  { id: 2, nome: 'Maria' }\n];\n\nfunction Lista() {\n  return (\n    <ul>\n      {usuarios.map(user => (\n        <li key={user.id}>{user.nome}</li>\n      ))}\n    </ul>\n  );\n}\n\nSempre use key única!",
            tip: "Keys ajudam React a identificar quais itens mudaram",
          },
          {
            title: "Renderização Condicional",
            content:
              "Exiba conteúdo baseado em condições.\n\nIf/Else:\nfunction Login({ isLogado }) {\n  if (isLogado) {\n    return <h1>Bem-vindo!</h1>;\n  }\n  return <button>Login</button>;\n}\n\nOperador Ternário:\n{isLogado ? <h1>Bem-vindo!</h1> : <button>Login</button>}\n\nOperador Lógico:\n{isLogado && <h1>Bem-vindo!</h1>}",
            tip: "Use ternários para JSX, if/else fora do JSX",
          },
          {
            title: "Composição de Componentes",
            content:
              'Componentes podem conter outros componentes.\n\nExemplo:\nfunction Card({ children }) {\n  return <div className="card">{children}</div>;\n}\n\nUsando:\n<Card>\n  <h2>Título</h2>\n  <p>Conteúdo</p>\n</Card>\n\nchildren é um prop especial que contém o conteúdo dentro!',
            tip: "Decomponha componentes grandes em menores",
          },
        ],
        exercises: [
          "Crie uma lista de tarefas exibindo array de tasks",
          "Adicione/remova itens da lista dinamicamente",
          "Use renderização condicional para exibir mensagem se lista vazia",
          "Crie um componente que renderiza diferentes tipos de cards",
        ],
        project: "Catálogo de Produtos: lista de produtos com filtros e busca",
      },
      {
        week: 4,
        title: "Formulários e Validação",
        objectives: [
          "Criar formulários complexos",
          "Validar dados antes de enviar",
          "Usar bibliotecas de validação",
          "Exibir erros e feedback",
        ],
        image: "https://images.unsplash.com/photo-1516321318423-f06f70d504c0?w=800&h=400&fit=crop",
        introduction:
          "Formulários são a base para captar dados do usuário. Validação garante que os dados sejam corretos.",
        sections: [
          {
            title: "Validação Manual",
            content:
              "Valide sem bibliotecas.\n\nExemplo:\nfunction Formulario() {\n  const [email, setEmail] = useState('');\n  const [erro, setErro] = useState('');\n  \n  const handleSubmit = (e) => {\n    e.preventDefault();\n    if (!email.includes('@')) {\n      setErro('Email inválido');\n    } else {\n      setErro('');\n      console.log('Enviado!');\n    }\n  };\n  \n  return (\n    <form onSubmit={handleSubmit}>\n      <input value={email} onChange={e => setEmail(e.target.value)} />\n      {erro && <p>{erro}</p>}\n      <button>Enviar</button>\n    </form>\n  );\n}",
            tip: "Sempre valide antes de enviar dados",
          },
          {
            title: "Múltiplos Campos",
            content:
              'Gerencie vários campos.\n\nExemplo:\nconst [form, setForm] = useState({\n  nome: \'\',\n  email: \'\',\n  senha: \'\'\n});\n\nconst handleChange = (e) => {\n  setForm({\n    ...form,\n    [e.target.name]: e.target.value\n  });\n};\n\n<input name="nome" value={form.nome} onChange={handleChange} />\n<input name="email" value={form.email} onChange={handleChange} />\n<input name="senha" value={form.senha} onChange={handleChange} type="password" />',
            tip: "Use spread operator (...) para não perder dados",
          },
          {
            title: "Feedback Visual",
            content:
              "Dê feedback ao usuário.\n\nEstados:\nconst [loading, setLoading] = useState(false);\nconst [mensagem, setMensagem] = useState('');\n\nUsando:\n<button disabled={loading}>\n  {loading ? 'Enviando...' : 'Enviar'}\n</button>\n\n{mensagem && <p className={tipo}>{mensagem}</p>}\n\nClasses CSS para sucesso/erro:\n.sucesso { color: green; }\n.erro { color: red; }",
            tip: "Desabilite botão enquanto envia para evitar submissões múltiplas",
          },
        ],
        exercises: [
          "Crie formulário com validação de email",
          "Crie formulário com múltiplos campos",
          "Valide força de senha com feedback visual",
          "Exiba erros/sucesso após envio",
        ],
        project: "Formulário de Cadastro: nome, email, senha com validações completas",
      },
      {
        week: 5,
        title: "Projeto Final - Rede Social Simplificada",
        objectives: [
          "Integrar todos os conceitos aprendidos",
          "Criar aplicação completa",
          "Gerenciar estado complexo",
          "Boas práticas de desenvolvimento",
        ],
        image: "https://images.unsplash.com/photo-1633356122544-f134324ef6e2?w=800&h=400&fit=crop",
        introduction: "Parabéns! Você chegou ao projeto final onde construirá uma rede social simplificada.",
        sections: [
          {
            title: "Estrutura do Projeto",
            content:
              "Como organizar a aplicação.\n\nComponents:\n- Header: navegação\n- Feed: lista de posts\n- PostForm: criar novo post\n- PostCard: exibir individual\n- Sidebar: usuário/info\n\nState Global:\nUse Context API para compartilhar posts entre componentes.\n\nconst [posts, setPosts] = useState([]);\nconst [usuario, setUsuario] = useState(null);",
            tip: "Estruture bem, fica fácil adicionar funcionalidades",
          },
          {
            title: "Funcionalidades Principais",
            content:
              "O que sua rede social deve ter:\n\n• Criar posts com texto/foto\n• Listar todos os posts\n• Dar like em posts\n• Comentar em posts\n• Perfil de usuário\n• Seguir/deixar de seguir\n• LocalStorage para persistir dados\n\nCada funcionalidade = novo componente!",
            tip: "Comece simples, depois adicione funcionalidades",
          },
          {
            title: "Fluxo de Dados",
            content:
              "Como os dados fluem.\n\nApp (estado global)\n├── Header\n├── Feed\n│   └── PostCard (recebe post como prop)\n│       └── Likes/Comments\n├── PostForm (atualiza estado no App)\n└── Sidebar\n    └── PerfilUsuario\n\nProps fluem para baixo (↓)\nCallbacks fluem para cima (↑)",
            tip: "Lifting state up quando precisar compartilhar dados",
          },
        ],
        exercises: [
          "Crie estrutura de componentes",
          "Implemente criar/exibir posts",
          "Adicione sistema de likes",
          "Crie perfil de usuário",
          "Salve dados no localStorage",
        ],
        project:
          "Rede Social Completa:\n• Posts com foto, texto e data\n• Sistema de likes e comentários\n• Perfil de usuário com avatar\n• LocalStorage para persistir dados\n• Interface responsiva\n• Componentes bem organizados",
      },
    ],
  },
  {
    id: "gamedev-unity",
    title: "Game Dev com Unity",
    level: "Intermediário",
    color: "from-accent",
    weeks: [
      {
        week: 1,
        title: "Introdução ao Unity e C#",
        objectives: [
          "Familiarizar-se com a interface do Unity",
          "Aprender sintaxe básica de C#",
          "Entender GameObjects e componentes",
          "Criar primeiro script funcional",
        ],
        image: "https://images.unsplash.com/photo-1538481143235-e390a02e8816?w=800&h=400&fit=crop",
        introduction:
          "Unity é a engine de jogos mais popular. C# é a linguagem de programação que você usará. Começaremos com o básico da interface e sintaxe.",
        sections: [
          {
            title: "Interface do Unity",
            content:
              "Conheça a interface.\n\nPainéis principais:\n• Scene: edita o cenário do jogo\n• Game: visualiza como o jogo fica\n• Inspector: edita propriedades\n• Hierarchy: lista objetos da cena\n• Project: arquivos do projeto\n\nFluxo: Scene → Game → Play\n\nHierarquia e componentes:\nGameObject = Ator no jogo\nComponent = Propriedades/scripts do ator",
            tip: "Customize o layout como preferir em Window > Layouts",
          },
          {
            title: "Conceitos Básicos de C#",
            content:
              "Sintaxe básica.\n\nVariáveis:\npublic int velocidade = 5;\nprivate string nome = 'Player';\n\nMétodos:\npublic void Mover(float direcao) {\n  transform.Translate(direcao * velocidade * Time.deltaTime, 0, 0);\n}\n\nCiclo de Vida:\n• Awake(): inicialização\n• Start(): antes de primeira renderização\n• Update(): chamado todo frame\n• LateUpdate(): depois do Update\n• OnDestroy(): quando objeto é destruído",
            tip: "public variáveis aparecem no Inspector para editar",
          },
          {
            title: "Scripts e GameObjects",
            content:
              "Como scripts funcionam.\n\nCriar script:\nC# script na pasta Assets\n\nAsso de script a GameObject:\nSelecione GameObject → Drag script para Inspector\n\nScript básico:\npublic class Jogador : MonoBehaviour {\n  public float velocidade = 5f;\n  \n  void Update() {\n    float x = Input.GetAxis('Horizontal');\n    transform.Translate(x * velocidade * Time.deltaTime, 0, 0);\n  }\n}\n\nTime.deltaTime garante movimento constante!",
            tip: "Não use float, use Time.deltaTime em cálculos de movimento",
          },
        ],
        exercises: [
          "Explore a interface do Unity",
          "Crie um GameObject com um cubo",
          "Crie um script C# simples que imprime no console",
          "Atribua script ao cubo e veja funcionar",
        ],
        project: "Cubo Rotativo: crie um cubo que rotaciona continuamente com script",
      },
      {
        week: 2,
        title: "Movimento e Entrada do Jogador",
        objectives: [
          "Responder a entrada do teclado",
          "Mover objetos no espaço",
          "Implementar câmera seguindo jogador",
          "Entender Rigidbody",
        ],
        image: "https://images.unsplash.com/photo-1552820728-8ac41f1ce891?w=800&h=400&fit=crop",
        introduction: "Agora você criará um jogador que se move com teclado e uma câmera que o segue.",
        sections: [
          {
            title: "Entrada do Teclado",
            content:
              "Como captar entrada.\n\nInput simples:\nif (Input.GetKey(KeyCode.W)) {\n  // Tecla W pressionada\n}\n\nInput com Axis (mais suave):\nfloat horizontal = Input.GetAxis('Horizontal');\nfloat vertical = Input.GetAxis('Vertical');\n\nMov:",
            tip: "GetAxis é melhor que GetKey para movimento",
          },
          {
            title: "Movimento do Jogador",
            content:
              "Mover o jogador.\n\nCom transform:\nvoid Update() {\n  float h = Input.GetAxis('Horizontal');\n  float v = Input.GetAxis('Vertical');\n  Vector3 movimento = new Vector3(h, 0, v) * velocidade * Time.deltaTime;\n  transform.Translate(movimento);\n}\n\nCom Rigidbody (recomendado):\nvoid Update() {\n  float h = Input.GetAxis('Horizontal');\n  rb.velocity = new Vector3(h * velocidade, rb.velocity.y, 0);\n}",
            tip: "Sempre use Time.deltaTime para movimento consistente",
          },
          {
            title: "Câmera Seguindo",
            content:
              "Câmera segue o jogador.\n\nScript para câmera:\npublic class CameraSeguidora : MonoBehaviour {\n  public Transform alvo;\n  public float velocidade = 5f;\n  public Vector3 offset = new Vector3(0, 5, -10);\n  \n  void LateUpdate() {\n    Vector3 posicaoDesejada = alvo.position + offset;\n    transform.position = Vector3.Lerp(transform.position, posicaoDesejada, velocidade * Time.deltaTime);\n    transform.LookAt(alvo);\n  }\n}\n\nUse LateUpdate para suave!",
            tip: "LateUpdate roda depois do Update, ideal para câmera",
          },
        ],
        exercises: [
          "Crie jogador que se move com WASD",
          "Implemente câmera isométrica seguindo jogador",
          "Adicione rotação do jogador para direção do movimento",
          "Crie limite de movimento na cena",
        ],
        project: "Jogo 3D simples: jogador se move, câmera segue, evita obstáculos",
      },
    ],
  },
]

function getCourseData(cursoId) {
  return cursosData.find((c) => c.id === cursoId)
}

export default function AulaPage({ params }) {
  const { cursoId, semanaNum } = params

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [semanaNum])

  const course = getCourseData(cursoId)
  const currentWeekNum = Number.parseInt(semanaNum)
  const week = course?.weeks.find((w) => w.week === currentWeekNum)

  if (!course || !week) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Aula não encontrada</h1>
          <Link href="/" className="text-primary hover:underline">
            Voltar para home
          </Link>
        </div>
      </div>
    )
  }

  const nextWeek = currentWeekNum + 1
  const hasNextWeek = course.weeks.some((w) => w.week === nextWeek)
  const prevWeek = currentWeekNum - 1
  const hasPrevWeek = prevWeek > 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header da aula */}
      <header className="border-b border-border sticky top-0 z-40 bg-background/95 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href="/" className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-4">
            <ChevronLeft size={20} />
            Voltar para Cursos
          </Link>
          <h1 className="text-3xl font-bold mb-2">{course.title}</h1>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="px-3 py-1 bg-muted rounded-full">{course.level}</span>
            <div className="flex items-center gap-1">
              <Clock size={16} />
              Semana {currentWeekNum} de {course.weeks.length}
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo principal */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="space-y-8">
          {/* Progresso */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Progresso</h2>
              <span className="text-sm font-medium">
                {currentWeekNum} de {course.weeks.length}
              </span>
            </div>
            <div className="w-full h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500"
                style={{
                  width: `${(currentWeekNum / course.weeks.length) * 100}%`,
                }}
              ></div>
            </div>
          </div>

          {/* Imagem principal */}
          <div className="relative h-64 sm:h-80 rounded-xl overflow-hidden border border-border">
            <img src={week.image || "/placeholder.svg"} alt={week.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/80 backdrop-blur rounded-full">
                  <BookOpen size={16} />
                  <span className="text-sm font-semibold">Semana {currentWeekNum}</span>
                </div>
                <h1 className="text-3xl sm:text-4xl font-bold text-white">{week.title}</h1>
              </div>
            </div>
          </div>

          {/* Introdução */}
          <div className="bg-card rounded-xl border border-border p-6">
            <p className="text-lg text-muted-foreground leading-relaxed">{week.introduction}</p>
          </div>

          {/* Objetivos */}
          <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl border border-primary/20 p-8">
            <div className="flex items-start gap-4">
              <Target size={32} className="text-primary flex-shrink-0 mt-1" />
              <div>
                <h2 className="text-2xl font-bold mb-4">Objetivos dessa Semana</h2>
                <ul className="space-y-3">
                  {week.objectives.map((obj, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle size={20} className="text-secondary flex-shrink-0 mt-1" />
                      <span className="text-foreground">{obj}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Seções de Conteúdo */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Conteúdo da Semana</h2>
            {week.sections.map((section, i) => (
              <div
                key={i}
                className="bg-card rounded-xl border border-border overflow-hidden hover:border-primary/50 transition"
              >
                <div className="p-6 space-y-4">
                  <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                    <Lightbulb size={24} />
                    {section.title}
                  </h3>
                  <div className="prose prose-invert max-w-none">
                    <div className="whitespace-pre-wrap text-base leading-relaxed text-muted-foreground font-mono bg-muted/50 p-4 rounded-lg overflow-x-auto">
                      {section.content}
                    </div>
                  </div>
                  <div className="bg-secondary/10 border border-secondary/30 rounded-lg p-4 flex items-start gap-3">
                    <Lightbulb size={20} className="text-secondary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-secondary mb-1">Dica</p>
                      <p className="text-sm text-muted-foreground">{section.tip}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Exercícios */}
          <div className="bg-card rounded-xl border border-border p-8 space-y-4">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <CheckCircle size={28} className="text-secondary" />
              Exercícios Práticos
            </h2>
            <div className="grid gap-3">
              {week.exercises.map((exercise, i) => (
                <div key={i} className="flex gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold text-primary">{i + 1}</span>
                  </div>
                  <p className="text-foreground">{exercise}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Projeto */}
          <div className="bg-gradient-to-br from-accent/20 to-primary/20 rounded-xl border border-accent/30 p-8 space-y-4">
            <h2 className="text-2xl font-bold">Projeto da Semana</h2>
            <p className="text-lg text-muted-foreground whitespace-pre-wrap">{week.project}</p>
            <Link
              href={`/curso/${cursoId}/semana/${currentWeekNum}/projeto`}
              className="inline-block mt-4 px-6 py-3 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold rounded-lg hover:shadow-lg transition"
            >
              Submeter Projeto
            </Link>
          </div>

          {/* Navegação entre semanas */}
          <div className="flex gap-4 pt-8 border-t border-border">
            {hasPrevWeek ? (
              <Link
                href={`/curso/${cursoId}/semana/${prevWeek}`}
                className="flex-1 py-3 px-4 bg-muted border border-border rounded-lg font-medium hover:bg-muted/80 transition flex items-center justify-center gap-2"
              >
                <ChevronLeft size={20} />
                Semana Anterior
              </Link>
            ) : (
              <div className="flex-1 py-3 px-4 bg-muted/50 border border-border rounded-lg font-medium opacity-50 flex items-center justify-center gap-2 cursor-not-allowed">
                <ChevronLeft size={20} />
                Semana Anterior
              </div>
            )}

            {hasNextWeek ? (
              <Link
                href={`/curso/${cursoId}/semana/${nextWeek}`}
                className="flex-1 py-3 px-4 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold rounded-lg hover:shadow-lg transition flex items-center justify-center gap-2"
              >
                Próxima Semana
                <ChevronRight size={20} />
              </Link>
            ) : (
              <button className="flex-1 py-3 px-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold rounded-lg hover:shadow-lg transition flex items-center justify-center gap-2">
                <CheckCircle size={20} />
                Curso Concluído!
              </button>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
