"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, CheckCircle, XCircle, Star, Send } from "lucide-react"

const cursosData = [
  {
    id: "javascript-fundamentos",
    title: "Fundamentos de JavaScript",
    weeks: [
      {
        week: 1,
        title: "Variáveis, Tipos e Operadores",
        quiz: [
          {
            id: 1,
            pergunta: "Qual a diferença entre 'let' e 'const'?",
            opcoes: [
              { texto: "'let' pode ser reatribuído, 'const' não", correto: true },
              { texto: "Não há diferença, são sinônimos", correto: false },
              { texto: "'const' é mais rápido", correto: false },
              { texto: "'let' só funciona em loops", correto: false },
            ],
          },
          {
            id: 2,
            pergunta: "O que typeof 42 retorna?",
            opcoes: [
              { texto: "'número'", correto: false },
              { texto: "'number'", correto: true },
              { texto: "'int'", correto: false },
              { texto: "'número inteiro'", correto: false },
            ],
          },
          {
            id: 3,
            pergunta: "Qual operador compara valor E tipo?",
            opcoes: [
              { texto: "==", correto: false },
              { texto: "=", correto: false },
              { texto: "===", correto: true },
              { texto: "!==", correto: false },
            ],
          },
        ],
      },
      {
        week: 2,
        title: "Funções, Loops e Condições",
        quiz: [
          {
            id: 1,
            pergunta: "Qual a sintaxe de uma arrow function?",
            opcoes: [
              { texto: "function (x) => x * 2", correto: false },
              { texto: "(x) => x * 2", correto: true },
              { texto: "function => (x) x * 2", correto: false },
              { texto: "(x) => {return x * 2;}", correto: true },
            ],
          },
          {
            id: 2,
            pergunta: "O que um loop while faz?",
            opcoes: [
              { texto: "Itera um número específico de vezes", correto: false },
              { texto: "Repete enquanto condição é verdadeira", correto: true },
              { texto: "Espera um tempo", correto: false },
              { texto: "Pausa a execução", correto: false },
            ],
          },
          {
            id: 3,
            pergunta: "Quando usar switch vs if/else?",
            opcoes: [
              { texto: "Sempre use if/else", correto: false },
              { texto: "Switch para múltiplas comparações simples", correto: true },
              { texto: "Switch é mais lento", correto: false },
              { texto: "Não há diferença", correto: false },
            ],
          },
        ],
      },
      {
        week: 3,
        title: "DOM e Manipulação de Eventos",
        quiz: [
          {
            id: 1,
            pergunta: "Como selecionar um elemento por ID?",
            opcoes: [
              { texto: "document.getElement('id')", correto: false },
              { texto: "document.getElementById('id')", correto: true },
              { texto: "document.querySelector('#id')", correto: true },
              { texto: "document.get('id')", correto: false },
            ],
          },
          {
            id: 2,
            pergunta: "O que addEventListener faz?",
            opcoes: [
              { texto: "Remove um elemento", correto: false },
              { texto: "Aguarda resposta a eventos", correto: true },
              { texto: "Adiciona estilos", correto: false },
              { texto: "Muda o HTML", correto: false },
            ],
          },
          {
            id: 3,
            pergunta: "Como mudar a classe CSS de um elemento?",
            opcoes: [
              { texto: "element.class = 'nova'", correto: false },
              { texto: "element.classList.add('nova')", correto: true },
              { texto: "element.addClass('nova')", correto: false },
              { texto: "element.style.class = 'nova'", correto: false },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "react-zero",
    title: "React do Zero",
    weeks: [
      {
        week: 1,
        title: "Conceitos Básicos e JSX",
        quiz: [
          {
            id: 1,
            pergunta: "O que é JSX?",
            opcoes: [
              { texto: "Uma linguagem de programação", correto: false },
              { texto: "Uma mistura de JavaScript e HTML", correto: true },
              { texto: "Um banco de dados", correto: false },
              { texto: "Um framework CSS", correto: false },
            ],
          },
          {
            id: 2,
            pergunta: "Componentes devem começar com letra maiúscula?",
            opcoes: [
              { texto: "Não, não importa", correto: false },
              { texto: "Sim, é obrigatório", correto: true },
              { texto: "Apenas em production", correto: false },
              { texto: "Depende da versão", correto: false },
            ],
          },
          {
            id: 3,
            pergunta: "Props são usadas para?",
            opcoes: [
              { texto: "Armazenar dados do servidor", correto: false },
              { texto: "Passar dados de pai para filho", correto: true },
              { texto: "Alterar o CSS globalmente", correto: false },
              { texto: "Executar loops", correto: false },
            ],
          },
        ],
      },
    ],
  },
]

function getCourseWeekData(cursoId, semanaNum) {
  const course = cursosData.find((c) => c.id === cursoId)
  const week = course?.weeks.find((w) => w.week === Number(semanaNum))
  return { course, week }
}

export default function ProjetoPage({ params }) {
  const { cursoId, semanaNum } = params
  const { course, week } = getCourseWeekData(cursoId, semanaNum)

  const [stage, setStage] = useState("quiz") // 'quiz' ou 'avaliacao'
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [answered, setAnswered] = useState(false)
  const [selectedAnswer, setSelectedAnswer] = useState(null)

  // Avaliação
  const [dificuldade, setDificuldade] = useState(0)
  const [clareza, setClareza] = useState(0)
  const [interesse, setInteresse] = useState(0)
  const [comentario, setComentario] = useState("")
  const [enviado, setEnviado] = useState(false)

  if (!course || !week) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Semana não encontrada</h1>
          <Link href="/" className="text-primary hover:underline">
            Voltar para home
          </Link>
        </div>
      </div>
    )
  }

  const quiz = week.quiz || []

  const handleAnswerClick = (opcaoIndex, isCorreto) => {
    setSelectedAnswer(opcaoIndex)
    setAnswered(true)
    if (isCorreto) {
      setScore(score + 1)
    }
  }

  const handleNextQuestion = () => {
    if (currentQuestion < quiz.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(null)
      setAnswered(false)
    } else {
      setStage("avaliacao")
    }
  }

  const handleSubmitAvaliacao = () => {
    if (dificuldade === 0 || clareza === 0 || interesse === 0) {
      alert("Por favor, responda todas as avaliações!")
      return
    }

    const avaliacoes = JSON.parse(localStorage.getItem("avaliacoes") || "[]")
    avaliacoes.push({
      cursoId,
      semanaNum,
      score: `${score}/${quiz.length}`,
      dificuldade,
      clareza,
      interesse,
      comentario,
      data: new Date().toLocaleDateString("pt-BR"),
    })
    localStorage.setItem("avaliacoes", JSON.stringify(avaliacoes))

    setEnviado(true)
    setTimeout(() => {
      alert(`Parabéns! Você acertou ${score} de ${quiz.length} perguntas! 🎉`)
      window.location.href = `/curso/${cursoId}/semana/${semanaNum}`
    }, 1500)
  }

  // Estágio Quiz
  if (stage === "quiz") {
    const pergunta = quiz[currentQuestion]
    const percentualProgress = ((currentQuestion + 1) / quiz.length) * 100

    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border sticky top-0 z-40 bg-background/95 backdrop-blur">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <Link
              href={`/curso/${cursoId}/semana/${semanaNum}`}
              className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-4"
            >
              <ChevronLeft size={20} />
              Voltar para Aula
            </Link>
            <h1 className="text-3xl font-bold">Quiz - {week.title}</h1>
            <p className="text-muted-foreground mt-2">Teste seus conhecimentos!</p>
          </div>
        </header>

        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* Progresso */}
          <div className="mb-8 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-semibold">
                Pergunta {currentQuestion + 1} de {quiz.length}
              </span>
              <span className="text-sm font-semibold text-primary">{Math.round(percentualProgress)}%</span>
            </div>
            <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-primary to-secondary transition-all"
                style={{ width: `${percentualProgress}%` }}
              ></div>
            </div>
          </div>

          {/* Pergunta */}
          <div className="bg-card rounded-xl border border-border p-8 mb-8">
            <h2 className="text-2xl font-bold mb-8">{pergunta.pergunta}</h2>

            {/* Opções */}
            <div className="grid gap-4">
              {pergunta.opcoes.map((opcao, index) => {
                const isSelected = selectedAnswer === index
                const showCorrect = answered && opcao.correto
                const showIncorrect = answered && isSelected && !opcao.correto

                return (
                  <button
                    key={index}
                    onClick={() => !answered && handleAnswerClick(index, opcao.correto)}
                    disabled={answered}
                    className={`p-4 text-left rounded-lg border-2 transition-all ${
                      showCorrect
                        ? "border-green-500 bg-green-500/10"
                        : showIncorrect
                          ? "border-red-500 bg-red-500/10"
                          : isSelected && !answered
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50"
                    } ${answered ? "cursor-not-allowed" : "cursor-pointer"}`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                          showCorrect
                            ? "border-green-500 bg-green-500"
                            : showIncorrect
                              ? "border-red-500 bg-red-500"
                              : isSelected && !answered
                                ? "border-primary bg-primary"
                                : "border-muted-foreground"
                        }`}
                      >
                        {showCorrect && <CheckCircle size={16} className="text-white" />}
                        {showIncorrect && <XCircle size={16} className="text-white" />}
                      </div>
                      <span className="text-lg">{opcao.texto}</span>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Feedback */}
            {answered && (
              <div
                className={`mt-8 p-4 rounded-lg border-2 ${
                  selectedAnswer !== null && pergunta.opcoes[selectedAnswer].correto
                    ? "border-green-500 bg-green-500/10"
                    : "border-red-500 bg-red-500/10"
                }`}
              >
                <p className="font-semibold flex items-center gap-2">
                  {selectedAnswer !== null && pergunta.opcoes[selectedAnswer].correto ? (
                    <>
                      <CheckCircle size={20} className="text-green-500" />
                      Correto! Muito bem!
                    </>
                  ) : (
                    <>
                      <XCircle size={20} className="text-red-500" />
                      Que pena! Tente novamente na próxima.
                    </>
                  )}
                </p>
              </div>
            )}
          </div>

          {/* Botão Próxima */}
          {answered && (
            <button
              onClick={handleNextQuestion}
              className="w-full py-4 px-6 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold rounded-lg hover:shadow-lg transition"
            >
              {currentQuestion === quiz.length - 1 ? "Ir para Avaliação" : "Próxima Pergunta"}
            </button>
          )}
        </main>
      </div>
    )
  }

  // Estágio Avaliação
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 z-40 bg-background/95 backdrop-blur">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link
            href={`/curso/${cursoId}/semana/${semanaNum}`}
            className="inline-flex items-center gap-2 text-primary hover:text-primary/80 mb-4"
          >
            <ChevronLeft size={20} />
            Voltar para Aula
          </Link>
          <h1 className="text-3xl font-bold">Avalie a Semana</h1>
          <p className="text-muted-foreground mt-2">Sua opinião nos ajuda a melhorar!</p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Resultado do Quiz */}
        <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl border border-primary/30 p-8 mb-8">
          <div className="text-center">
            <h2 className="text-4xl font-bold mb-4">
              {score}/{quiz.length} Corretas!
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Você acertou {Math.round((score / quiz.length) * 100)}% das questões!
            </p>
            {score === quiz.length && (
              <p className="text-xl font-bold text-green-500">🎉 Perfeito! Você domina este conteúdo!</p>
            )}
            {score >= quiz.length * 0.7 && score < quiz.length && (
              <p className="text-xl font-bold text-yellow-500">⭐ Ótimo! Você está no caminho certo!</p>
            )}
            {score < quiz.length * 0.7 && (
              <p className="text-xl font-bold text-blue-500">📚 Continue estudando, você consegue!</p>
            )}
          </div>
        </div>

        {/* Avaliação */}
        <div className="bg-card rounded-xl border border-border p-8 space-y-8">
          <h2 className="text-2xl font-bold">Avalie esta Semana</h2>

          {/* Dificuldade */}
          <div className="space-y-3">
            <label className="text-lg font-semibold">Qual foi a dificuldade do conteúdo?</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((nivel) => (
                <button
                  key={nivel}
                  onClick={() => setDificuldade(nivel)}
                  className={`p-3 rounded-lg border-2 transition ${
                    dificuldade === nivel ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                  }`}
                >
                  <Star
                    size={24}
                    className={dificuldade >= nivel ? "fill-yellow-500 text-yellow-500" : "text-muted-foreground"}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">1 = Muito fácil | 5 = Muito difícil</p>
          </div>

          {/* Clareza */}
          <div className="space-y-3">
            <label className="text-lg font-semibold">Como foi a clareza das explicações?</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((nivel) => (
                <button
                  key={nivel}
                  onClick={() => setClareza(nivel)}
                  className={`p-3 rounded-lg border-2 transition ${
                    clareza === nivel ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                  }`}
                >
                  <Star
                    size={24}
                    className={clareza >= nivel ? "fill-green-500 text-green-500" : "text-muted-foreground"}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">1 = Confusa | 5 = Muito clara</p>
          </div>

          {/* Interesse */}
          <div className="space-y-3">
            <label className="text-lg font-semibold">Quanto interesse você teve no assunto?</label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((nivel) => (
                <button
                  key={nivel}
                  onClick={() => setInteresse(nivel)}
                  className={`p-3 rounded-lg border-2 transition ${
                    interesse === nivel ? "border-primary bg-primary/10" : "border-border hover:border-primary/50"
                  }`}
                >
                  <Star
                    size={24}
                    className={interesse >= nivel ? "fill-blue-500 text-blue-500" : "text-muted-foreground"}
                  />
                </button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">1 = Sem interesse | 5 = Muito interessante</p>
          </div>

          {/* Comentário */}
          <div className="space-y-3">
            <label className="text-lg font-semibold">Deixe um comentário (opcional)</label>
            <textarea
              value={comentario}
              onChange={(e) => setComentario(e.target.value)}
              placeholder="Compartilhe seus pensamentos, sugestões ou dúvidas..."
              className="w-full h-24 p-4 bg-background rounded-lg border border-border resize-none focus:outline-none focus:border-primary text-foreground"
            />
            <p className="text-xs text-muted-foreground">{comentario.length} caracteres</p>
          </div>

          {/* Botão Submit */}
          <button
            onClick={handleSubmitAvaliacao}
            disabled={enviado}
            className="w-full py-4 px-6 bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold rounded-lg hover:shadow-lg transition disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {enviado ? (
              <>
                <CheckCircle size={20} />
                Enviando...
              </>
            ) : (
              <>
                <Send size={20} />
                Submeter Avaliação
              </>
            )}
          </button>
        </div>
      </main>
    </div>
  )
}
