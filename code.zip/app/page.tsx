import Header from "@/components/header"
import Hero from "@/components/hero"
import Courses from "@/components/courses"
import Features from "@/components/features"
import Projects from "@/components/projects"
import Community from "@/components/community"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Features />
      <Courses />
      <Projects />
      <Community />
      <Footer />
    </main>
  )
}
